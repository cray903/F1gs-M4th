document.addEventListener('DOMContentLoaded', () => {
    const starsContainer = document.querySelector('.stars-container');
    const numberOfStars = 200; // Adjust number of stars for desired density

    for (let i = 0; i < numberOfStars; i++) {
        const star = document.createElement('div');
        star.classList.add('star');

        // Random position within the viewport
        const x = Math.random() * 100; // Percentage of viewport width
        const y = Math.random() * 100; // Percentage of viewport height
        star.style.left = `${x}vw`;
        star.style.top = `${y}vh`;

        // Random animation delay and duration for varied twinkling
        const animationDuration = Math.random() * 4 + 2; // 2 to 6 seconds
        const animationDelay = Math.random() * animationDuration; // Delay up to the duration
        star.style.animationDuration = `${animationDuration}s`;
        star.style.animationDelay = `-${animationDelay}s`; // Use negative delay to start animation at a random point

        starsContainer.appendChild(star);
    }

    // --- Get References to various page sections/elements ---
    const initialScreen = document.getElementById('initialScreen');
    const proceedButton = document.getElementById('proceedButton');
    const homeContent = document.getElementById('homeContent'); // Reference to the home page content div
    const siteLogo = document.getElementById('siteLogo'); // Reference to the site logo div (now also home button)
    const discordLink = document.getElementById('discordLink'); // Reference to the Discord link
    const partnersButton = document.getElementById('partnersButton'); // Reference to the Partners button (re-added)
    const settingsButton = document.getElementById('settingsButton'); // Reference to the Settings button
    const gamesButton = document.getElementById('gamesButton'); // Reference to the Games button
    const settingsMenu = document.getElementById('settingsMenu'); // Reference to the settings menu
    const body = document.body; // Reference to the body for theme changes
    const partyTitle = document.getElementById('partyTitle'); // Reference to the h1 for party mode

    // --- Games Elements ---
    const gamesListContainer = document.getElementById('gamesListContainer'); // The games page container
    const gamesGrid = document.getElementById('gamesGrid'); // The grid inside the container
    const gameIframeContainer = document.getElementById('gameIframeContainer');
    const gameIframe = document.getElementById('gameIframe');
    const closeGameButton = document.getElementById('closeGameButton');
    const fullscreenGameButton = document.getElementById('fullscreenGameButton');

    // --- Partner Page Elements ---
    const partnerPageContainer = document.getElementById('partnerPageContainer'); // The partner page container

    // --- Themes Page Elements ---
    const themesPageContainer = document.getElementById('themesPageContainer'); // The themes page container
    const themesGrid = document.getElementById('themesGrid'); // The grid inside the themes container
    const browseThemesButton = document.getElementById('browseThemesButton'); // Button in settings menu to browse themes

    // --- About Page Elements ---
    const aboutButton = document.getElementById('aboutButton'); // Reference to the new About button
    const aboutPageContainer = document.getElementById('aboutPageContainer'); // The about page container

    // Array of available games
    // Added an 'image' property for potential future use, but currently using a placeholder
    // Added 'description' property
    const availableGames = [
        { name: 'Subway Surfers', url: 'https://worldunion.info/assets/g/subway-surfers-ny/', image: 'img_9060.webp', description: 'Run from the grumpy inspector and his dog in this endless runner!' },
        { name: 'Retro Bowl', url: 'https://usewaves.site/assets/g/retrobowl/', image: 'Retro_Bowl.webp', description: 'Manage and play American football in a retro pixel art style.' },
        { name: 'FNaF 1', url: 'https://usewaves.site/assets/g/fnaf/', image: 'FNaF1.webp', description: 'Survive five nights as a security guard at Freddy Fazbear\'s Pizza.' },
        // Add more games here in the future
        // { name: 'Another Cool Game', url: 'https://example.com/another-game/', image: 'path/to/image.png' },
        { name: 'Slope', url: 'https://usewaves.site/assets/g/slope/', image: '/1665591257867_63292513ab017d84f57e52f618abdaec.jpeg', description: 'Navigate a ball down a tricky slope, avoiding obstacles.' },
        { name: 'Plants VS Zombies', url: 'https://usewaves.site/assets/g/pvz/', image: 'image-2.webp', description: 'Defend your home from zombies using a variety of plants with unique abilities!' },
        // Add Basketball Stars
        { name: 'Basketball Stars', url: 'https://usewaves.site/assets/g/basketball-stars/', image: '/cover-1583231506155.avif', description: 'Play exciting one-on-one basketball matches against famous stars!' },
        // Add Friday Night Funkin'
        { name: 'Friday Night Funkin\'', url: 'https://usewaves.site/assets/g/fridaynightfunkin/', image: '/enlarged.avif', description: 'A rhythm game where you battle characters through rap and singing!' },
        // Add Happy Wheels
        { name: 'Happy Wheels', url: 'https://usewaves.site/assets/g/happywheels/', image: '/hq720.jpg', description: 'A ragdoll physics-based game where players navigate various vehicles through dangerous courses.' },
        // Add Minecraft
        { name: 'Minecraft', url: 'https://usewaves.site/assets/g/eg1.8/index.html', image: '/a28a81253e919298beab2295e39a56b7a5140ef15abdb56135655e5c221b2a3a.avif', description: 'Explore, build, and survive in a blocky, procedurally generated world.' },
        // Add Cookie Clicker
        { name: 'Cookie Clicker', url: 'https://usewaves.site/assets/g/cookieclicker/', image: '/Screenshot_20250608_204946_Chrome.jpg', description: 'Click the giant cookie to earn cookies and buy upgrades!' },
    ];

    // Array of available themes
    const availableThemes = [
        { name: 'Dark', class: 'theme-dark', preview: { bgColor: '#333', textColor: 'white' } },
        { name: 'Light', class: 'theme-light', preview: { bgColor: '#f0f0f0', textColor: '#333' } },
        { name: 'Space', class: 'theme-space', preview: { bgColor: '#0f0c29', textColor: 'white', effect: 'stars' } }, // Added effect explicitly
        { name: 'Grimace', class: 'theme-grimace', preview: { bgColor: '#6A0DAD', textColor: 'white' } },
        { name: 'Cyberpunk', class: 'theme-cyberpunk', preview: { bgColor: '#1a1a2e', textColor: '#00ffff' } },
        { name: 'Ocean Breeze', class: 'theme-ocean-breeze', preview: { bgColor: '#e0f7fa', textColor: '#004d40' } },
        { name: 'Volcano', class: 'theme-volcano', preview: { bgColor: '#212121', textColor: '#ff5722' } },
        { name: 'Mint', class: 'theme-mint', preview: { bgColor: '#e0f2f7', textColor: '#004d40' } }, // Light pastel green/blue
        { name: 'Lavender', class: 'theme-lavender', preview: { bgColor: '#f3e5f5', textColor: '#4a148c' } }, // Light pastel purple
        { name: 'Forest', class: 'theme-forest', preview: { bgColor: '#2e7d32', textColor: '#e8f5e9' } }, // Dark green
        { name: 'Sunset', class: 'theme-sunset', preview: { bgColor: '#ffccbc', textColor: '#bf360c' } }, // Orange/Red
        { name: 'Snowy Hills', class: 'theme-snowy-hills', preview: { bgColor: '#e3f2fd', textColor: '#1a237e' }, effect: 'snow' }, // Blue/White with snow
        { name: 'Rainy Day', class: 'theme-rainy-day', preview: { bgColor: '#b0bec5', textColor: '#263238' }, effect: 'rain' }, // Grey/Blue with rain
         { name: 'Desert', class: 'theme-desert', preview: { bgColor: '#fff9c4', textColor: '#e65100' } }, // Sand/Orange
         { name: 'Deep Sea', class: 'theme-deep-sea', preview: { bgColor: '#01579b', textColor: '#b3e5fc' } }, // Deep blue/Light blue
         { name: 'Candy Pop', class: 'theme-candy-pop', preview: { bgColor: '#f8bbd0', textColor: '#880e4f' } }, // Pink/Dark Pink
         { name: 'Mystic Night', class: 'theme-mystic-night', preview: { bgColor: '#260b3b', textColor: '#e1bee7' } }, // Dark purple/Light purple
         { name: 'Volcanic Ash', class: 'theme-volcanic-ash', preview: { bgColor: '#424242', textColor: '#bdbdbd' } }, // Dark grey/Light grey
         { name: 'Sunrise', class: 'theme-sunrise', preview: { bgColor: '#ffeb3b', textColor: '#f57c00' } }, // Yellow/Orange
         { name: 'Twilight', class: 'theme-twilight', preview: { bgColor: '#512da8', textColor: '#e1bee7' } }, // Deep Purple/Light Purple
         { name: 'Cherry Blossom', class: 'theme-cherry-blossom', preview: { bgColor: '#fce4ec', textColor: '#880e4f' } }, // Very Light Pink/Dark Pink
         { name: 'Emerald', class: 'theme-emerald', preview: { bgColor: '#00796b', textColor: '#b2dfdb' } }, // Dark Teal/Light Teal
         { name: 'Ruby', class: 'theme-ruby', preview: { bgColor: '#b71c1c', textColor: '#ffcdd2' } }, // Dark Red/Light Red
         { name: 'Sapphire', class: 'theme-sapphire', preview: { bgColor: '#0d47a1', textColor: '#bbdefb' } }, // Dark Blue/Light Blue
         { name: 'Amethyst', class: 'theme-amethyst', preview: { bgColor: '#4a148c', textColor: '#e1bee7' } }, // Deep Purple/Light Purple
         { name: 'Bronze', class: 'theme-bronze', preview: { bgColor: '#3e2723', textColor: '#d7ccc8' } }, // Dark Brown/Light Grey-Brown
         { name: 'Silver', class: 'theme-silver', preview: { bgColor: '#757575', textColor: '#f5f5f5' } }, // Grey/Very Light Grey
         { name: 'Gold', class: 'theme-gold', preview: { bgColor: '#ffb300', textColor: '#424242' } }, // Dark Amber/Dark Grey
         { name: 'Galaxy', class: 'theme-galaxy', preview: { bgColor: '#1a0f2d', textColor: '#d1c4e9' }, effect: 'stars' }, // Very Dark Purple/Light Purple (using existing stars)
         { name: 'Aurora', class: 'theme-aurora', preview: { bgColor: '#004d40', textColor: '#a7ffeb' } }, // Dark Teal/Neon Green
         { name: 'Fire', class: 'theme-fire', preview: { bgColor: '#bf360c', textColor: '#ffeb3b' } }, // Dark Orange/Yellow
         { name: 'Ice', class: 'theme-ice', preview: { bgColor: '#e1f5fe', textColor: '#0277bd' } }, // Very Light Blue/Medium Blue
         // Adding 10 more placeholder themes
         { name: 'Forest Mist', class: 'theme-forest-mist', preview: { bgColor: '#cfd8dc', textColor: '#37474f' } }, // Light Blue Grey/Dark Grey
         { name: 'Grapevine', class: 'theme-grapevine', preview: { bgColor: '#6a1b9a', textColor: '#f3e5f5' } }, // Dark Purple/Light Pink
         { name: 'Steel Blue', class: 'theme-steel-blue', preview: { bgColor: '#455a64', textColor: '#eceff1' } }, // Dark Blue Grey/Very Light Blue Grey
         { name: 'Crimson', class: 'theme-crimson', preview: { bgColor: '#d32f2f', textColor: '#ffcdd2' } }, // Red/Light Red
         { name: 'Olive Grove', class: 'theme-olive-grove', preview: { bgColor: '#827717', textColor: '#f1f8e9' } }, // Dark Olive/Very Light Green
         { name: 'Coral Reef', class: 'theme-coral-reef', preview: { bgColor: '#ffab91', textColor: '#d84315' } }, // Medium Orange/Dark Orange
         { name: 'Midnight', class: 'theme-midnight', preview: { bgColor: '#212121', textColor: '#757575' } }, // Dark Grey/Grey
         { name: 'Ocean Sunset', class: 'theme-ocean-sunset', preview: { bgColor: '#004d40', textColor: '#ffab91' } }, // Dark Teal/Medium Orange
         { name: 'Pastel Dream', class: 'theme-pastel-dream', preview: { bgColor: '#f8bbd0', textColor: '#80cbc4' } }, // Light Pink/Medium Teal
         { name: 'Volcano Smoke', class: 'theme-volcano-smoke', preview: { bgColor: '#424242', textColor: '#ffccbc' } }, // Dark Grey/Light Orange
        { name: 'Custom', class: 'theme-custom', preview: { bgColor: '#333333', textColor: '#ffffff' } }, // Add a "Custom" theme entry
    ];


    // Function to render the game list
    function renderGames() {
        gamesGrid.innerHTML = ''; // Clear current list
        availableGames.forEach(game => {
            const gameBox = document.createElement('div');
            gameBox.classList.add('game-box');
            // Added image element, title, description, and play button
            gameBox.innerHTML = `
                <img src="${game.image}" alt="${game.name} Thumbnail">
                <h3>${game.name}</h3>
                <p class="game-description">${game.description}</p> <!-- Added description paragraph -->
                <button class="play-game-button" data-game-url="${game.url}">Play</button>
            `;
             // Add a click listener to the entire game box
            gameBox.addEventListener('click', () => {
                 const gameUrl = game.url;
                 if (gameUrl) {
                    gamesListContainer.classList.add('hidden'); // Hide the games page
                    settingsMenu.classList.add('hidden'); // Hide settings menu
                    partnerPageContainer.classList.add('hidden'); // Hide partner page
                    themesPageContainer.classList.add('hidden'); // Hide themes page
                    aboutPageContainer.classList.add('hidden'); // Hide about page
                    gameIframe.src = gameUrl; // Set the iframe source
                    gameIframeContainer.classList.remove('hidden'); // Show the iframe container
                 }
            });
            // Prevent the button click from triggering the box click listener twice
             gameBox.querySelector('.play-game-button').addEventListener('click', (event) => {
                event.stopPropagation(); // Stop the event from bubbling up to the gameBox
                const gameUrl = event.target.getAttribute('data-game-url');
                if (gameUrl) {
                   gamesListContainer.classList.add('hidden'); // Hide the games page
                   settingsMenu.classList.add('hidden'); // Hide settings menu
                   partnerPageContainer.classList.add('hidden'); // Hide partner page
                   themesPageContainer.classList.add('hidden'); // Hide themes page
                   aboutPageContainer.classList.add('hidden'); // Hide about page
                   gameIframe.src = gameUrl; // Set the iframe source
                   gameIframeContainer.classList.remove('hidden'); // Show the iframe container
                }
             });

            gamesGrid.appendChild(gameBox);
        });
    }

    // Function to render the theme list
    function renderThemes() {
        themesGrid.innerHTML = ''; // Clear current list
        availableThemes.forEach(theme => {
            const themeBox = document.createElement('div');
            themeBox.classList.add('theme-box');
            // Add a preview area and theme name
            themeBox.innerHTML = `
                <div class="theme-preview" style="background-color: ${theme.preview.bgColor}; color: ${theme.preview.textColor};">
                     Theme Preview
                </div>
                <h3>${theme.name}</h3>
            `;
             themeBox.addEventListener('click', () => {
                 // Apply the theme class to the body
                 applyTheme(theme.class, theme.effect);
                 // You might keep the themes page open, or hide it. Let's keep it open for now.
                 // themesPageContainer.classList.add('hidden');
             });

            themesGrid.appendChild(themeBox);
        });
    }


    // --- Settings Menu Elements (already have references above) ---
    const titleInput = document.getElementById('titleInput');
    const applyTitleButton = document.getElementById('applyTitleButton');
    const faviconInput = document.getElementById('faviconInput');
    const applyFaviconButton = document.getElementById('applyFaviconButton');
    const currentTimeElement = document.getElementById('currentTime');
    const themeButtons = document.querySelectorAll('.theme-button'); // Re-query after adding new buttons
    const faviconLink = document.getElementById('favicon');
    const openInBlankButton = document.getElementById('openInBlankButton'); // Add reference to new button
    const betterUiSwitch = document.getElementById('betterUiSwitch'); // Add reference to the new Better UI switch

    // Added references for custom theme inputs
    const bgColorInput = document.getElementById('bgColorInput');
    const textColorInput = document.getElementById('textColorInput');
    const applyCustomThemeButton = document.getElementById('applyCustomColorsButton'); // Renamed reference
    const generateThemeButton = document.getElementById('generateThemeButton'); // Reference to the new button
    const partyButton = document.getElementById('partyButton'); // Reference to the new Party button
    const confettiContainer = document.querySelector('.confetti-container');

    let partyModeInterval = null; // To store the interval ID for party mode
    let confettiInterval = null; // To store the interval ID for confetti
    let audioContext;
    let audioBuffer;
    let audioSource;

    // Function to load and play sound
    async function playSound(url) {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }

        if (audioBuffer && audioBuffer.url === url) {
             // If the same audio is already loaded, just play it
             if (audioSource) {
                audioSource.stop();
                audioSource.disconnect();
            }
            audioSource = audioContext.createBufferSource();
            audioSource.buffer = audioBuffer;
            audioSource.connect(audioContext.destination);
            audioSource.loop = true;
            audioSource.start(0);
            return;
        }

        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
            audioBuffer.url = url; // Store the URL with the buffer for comparison

            if (audioSource) {
                audioSource.stop(); // Stop previous playback if any
                audioSource.disconnect();
            }

            audioSource = audioContext.createBufferSource();
            audioSource.buffer = audioBuffer;
            audioSource.connect(audioContext.destination);
            audioSource.loop = true; // Loop the music
            audioSource.start(0);
        } catch (error) {
            console.error('Error loading or playing audio:', error);
            // Fallback for user gesture requirement if it fails immediately
            if (audioContext.state === 'suspended') {
                console.log('AudioContext suspended, trying to resume on user gesture.');
                const resumeAudio = () => {
                    audioContext.resume().then(() => {
                        console.log('AudioContext resumed!');
                        playSound(url); // Try playing again
                        document.removeEventListener('click', resumeAudio);
                        document.removeEventListener('keydown', resumeAudio);
                    });
                };
                document.addEventListener('click', resumeAudio, { once: true });
                document.addEventListener('keydown', resumeAudio, { once: true });
            }
        }
    }

    function stopSound() {
        if (audioSource) {
            audioSource.stop();
            audioSource.disconnect();
            audioSource = null;
        }
        if (audioContext && audioContext.state !== 'closed') {
            audioContext.close().then(() => {
                console.log('AudioContext closed!');
                audioContext = null;
                audioBuffer = null; // Clear buffer
            });
        }
    }

    // Function to create and drop confetti
    function createConfetti() {
        const confetti = document.createElement('div');
        confetti.classList.add('confetti');
        const colors = ['#f00', '#0f0', '#00f', '#ff0', '#0ff', '#f0f']; // Rainbow colors
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.backgroundColor = randomColor;
        confetti.style.left = `${Math.random() * 100}vw`; // Random horizontal position
        confetti.style.animationDuration = `${Math.random() * 2 + 3}s`; // 3-5 seconds fall
        confetti.style.animationDelay = `-${Math.random() * 5}s`; // Random start delay
        confettiContainer.appendChild(confetti);

        // Remove confetti after it falls off screen to prevent DOM overload
        confetti.addEventListener('animationend', () => {
            confetti.remove();
        });
    }


    // Add event listener for the About:Blank button
    openInBlankButton.addEventListener('click', () => {
        const win = window.open();
        win.document.body.style.margin = '0';
        win.document.body.style.height = '100vh';
        const iframe = win.document.createElement('iframe');
        iframe.style.border = 'none';
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        iframe.style.margin = '0';
        iframe.src = window.location.href;
        win.document.body.appendChild(iframe);
    });

    // Add event listener for the Better UI switch
    betterUiSwitch.addEventListener('change', () => {
        if (betterUiSwitch.checked) {
            body.classList.add('better-ui-active');
            localStorage.setItem('betterUiActive', 'true'); // Save state
        } else {
            body.classList.remove('better-ui-active');
            localStorage.setItem('betterUiActive', 'false'); // Save state
        }
    });

    // Add event listener for Apply Custom Colors button (now "Apply Custom Theme")
    applyCustomThemeButton.addEventListener('click', () => {
        const bgColor = bgColorInput.value;
        const textColor = textColorInput.value;
        // Set CSS variables directly on the root element
        document.documentElement.style.setProperty('--custom-bg', bgColor);
        document.documentElement.style.setProperty('--custom-text', textColor);

        // Apply the 'custom' theme class
        applyTheme('theme-custom'); // Apply the custom theme class

        // Save custom colors to local storage
        localStorage.setItem('savedBgColor', bgColor);
        localStorage.setItem('savedTextColor', textColor);
    });

    // Add event listener for Generate Theme button
    generateThemeButton.addEventListener('click', () => {
        // Generate random hex colors
        const randomBgColor = '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
        const randomTextColor = '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');

        // Update the color picker inputs
        bgColorInput.value = randomBgColor;
        textColorInput.value = randomTextColor;

        // Automatically apply the generated colors and the custom theme
        applyCustomThemeButton.click(); // Simulate a click on the Apply Custom Theme button
    });

    // Add event listener for Party Mode button
    partyButton.addEventListener('click', () => {
        if (partyModeInterval) {
            // Party mode is active, turn it off
            clearInterval(partyModeInterval);
            clearInterval(confettiInterval);
            partyModeInterval = null;
            confettiInterval = null;
            stopSound(); // Stop the music
            partyButton.textContent = 'Activate Party Mode 🎉';
            partyButton.classList.remove('active'); // Optional: Add/remove active class for styling
            body.classList.remove('party-mode-active'); // Remove class for bouncing text
            confettiContainer.classList.add('hidden'); // Hide confetti
            console.log('Party Mode Deactivated!');
        } else {
            // Party mode is off, turn it on
            partyModeInterval = setInterval(() => {
                generateThemeButton.click(); // Trigger theme generation
            }, 100); // Change theme every 100ms for a rapid effect
            
            confettiInterval = setInterval(createConfetti, 100); // Drop confetti every 100ms
            
            playSound('/ALL MY FELLAS REMIX.mp3'); // Start playing the music
            partyButton.textContent = 'Deactivate Party Mode 🛑';
            partyButton.classList.add('active'); // Optional: Add/remove active class for styling
            body.classList.add('party-mode-active'); // Add class for bouncing text
            confettiContainer.classList.remove('hidden'); // Show confetti
            console.log('Party Mode Activated! Prepare to party!');
        }
    });


    // --- Cloak Presets ---
    const cloakOptions = document.querySelectorAll('.cloak-option');

    // --- Function to update time ---
    function updateTime() {
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();

        // Convert to 12-hour format
        const ampm = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours % 12 === 0 ? 12 : hours % 12; // Handle 0 (midnight) and 12 (noon)
        const displayMinutes = minutes < 10 ? '0' + minutes : minutes;

        currentTimeElement.textContent = `${displayHours}:${displayMinutes} ${ampm}`;
    }

    // Update time initially and then every second
    updateTime();
    setInterval(updateTime, 1000);


    // --- Function to apply theme ---
    // Modified to accept theme class and effect
    function applyTheme(themeClass, effect = null) {
        // Find the current theme class on the body and remove it
        const currentThemeClass = Array.from(body.classList).find(cls => cls.startsWith('theme-'));
        if (currentThemeClass) {
            body.classList.remove(currentThemeClass);
        }

        // Remove any existing effect layers
        document.querySelectorAll('.effect-layer').forEach(layer => layer.remove());

        // Apply the new theme class
        body.classList.add(themeClass);

        // Apply effect if specified (and not 'stars', as stars are handled by default body styles)
        if (effect && effect !== 'stars') {
            const effectLayer = document.createElement('div');
            effectLayer.classList.add('effect-layer', `${effect}-effect-layer`);
            body.appendChild(effectLayer);
            localStorage.setItem('savedEffect', effect); // Save effect state
        } else {
            // If the new theme has no effect or the effect is 'stars', remove any saved effect
            localStorage.removeItem('savedEffect');
        }


        // Save the applied theme class to local storage
        localStorage.setItem('savedThemeClass', themeClass);

        // If applying 'custom', save colors. If applying others, clear custom colors.
        if (themeClass !== 'theme-custom') {
            localStorage.removeItem('savedBgColor');
            localStorage.removeItem('savedTextColor');
        }
    }


    // --- Event Listeners ---

    // Handle Proceed Button Click
    proceedButton.addEventListener('click', () => {
        // Hide initial screen
        initialScreen.classList.add('hidden');

        // Show home page content
        homeContent.classList.remove('hidden');

        // Show top-right icons (Discord, Settings, Games, Partners, About)
        discordLink.classList.remove('hidden'); // Show Discord
        partnersButton.classList.remove('hidden'); // Show Partners
        gamesButton.classList.remove('hidden'); // Show Games button
        aboutButton.classList.remove('hidden'); // Show About button
        settingsButton.classList.remove('hidden'); // Show Settings
    });

    // Handle Site Logo Click (now acts as Home button)
    siteLogo.addEventListener('click', () => {
        // Hide all main content views (except initial screen)
        homeContent.classList.add('hidden');
        gamesListContainer.classList.add('hidden'); // Hide games page
        partnerPageContainer.classList.add('hidden'); // Hide partner page
        themesPageContainer.classList.add('hidden'); // Hide themes page
        aboutPageContainer.classList.add('hidden'); // Hide about page
        gameIframeContainer.classList.add('hidden'); // Hide iframe container
        // Reset iframe source
        gameIframe.src = "";

        // Hide top-right icons
        discordLink.classList.add('hidden'); // Hide discord icon
        partnersButton.classList.add('hidden'); // Hide partners icon
        gamesButton.classList.add('hidden'); // Hide games icon
        aboutButton.classList.add('hidden'); // Hide about icon
        settingsButton.classList.add('hidden'); // Hide settings menu
        settingsMenu.classList.add('hidden'); // Hide settings menu if open

        // Show initial screen
        initialScreen.classList.remove('hidden');
    });

    // Toggle settings menu visibility
    settingsButton.addEventListener('click', (event) => {
        settingsMenu.classList.toggle('hidden'); // Toggle 'hidden' class
        // Hide other full pages if settings is opened from them? No, settings overlays.
        event.stopPropagation(); // Prevent click from closing immediately if it bubbles up
    });

    // Handle Games button click
    gamesButton.addEventListener('click', () => {
        homeContent.classList.add('hidden'); // Hide home content
        settingsMenu.classList.add('hidden'); // Hide settings menu
        partnerPageContainer.classList.add('hidden'); // Hide partner page
        themesPageContainer.classList.add('hidden'); // Hide themes page
        aboutPageContainer.classList.add('hidden'); // Hide about page
        gameIframeContainer.classList.add('hidden'); // Hide iframe if open
        gameIframe.src = ""; // Reset iframe source
        gamesListContainer.classList.remove('hidden'); // Show games page
    });

     // Handle Partners button click
     partnersButton.addEventListener('click', () => {
         homeContent.classList.add('hidden'); // Hide home content
         settingsMenu.classList.add('hidden'); // Hide settings menu
         gamesListContainer.classList.add('hidden'); // Hide games page
         themesPageContainer.classList.add('hidden'); // Hide themes page
         aboutPageContainer.classList.add('hidden'); // Hide about page
         gameIframeContainer.classList.add('hidden'); // Hide iframe if open
         gameIframe.src = ""; // Reset iframe source
         partnerPageContainer.classList.remove('hidden'); // Show partner page
     });

     // Handle "Browse All Themes" button click in settings menu
     browseThemesButton.addEventListener('click', () => {
         settingsMenu.classList.add('hidden'); // Hide settings menu
         homeContent.classList.add('hidden'); // Hide home content (if visible)
         gamesListContainer.classList.add('hidden'); // Hide games page (if visible)
         partnerPageContainer.classList.add('hidden'); // Hide partner page (if visible)
         aboutPageContainer.classList.add('hidden'); // Hide about page (if visible)
         gameIframeContainer.classList.add('hidden'); // Hide iframe (if visible)
         gameIframe.src = ""; // Reset iframe source
         themesPageContainer.classList.remove('hidden'); // Show themes page
     });

     // Handle "About" button click
     aboutButton.addEventListener('click', () => {
        homeContent.classList.add('hidden'); // Hide home content
        settingsMenu.classList.add('hidden'); // Hide settings menu
        gamesListContainer.classList.add('hidden'); // Hide games page
        partnerPageContainer.classList.add('hidden'); // Hide partner page
        themesPageContainer.classList.add('hidden'); // Hide themes page
        gameIframeContainer.classList.add('hidden'); // Hide iframe if open
        gameIframe.src = ""; // Reset iframe source
        aboutPageContainer.classList.remove('hidden'); // Show about page
     });


    // Close settings menu if clicked outside
    document.addEventListener('click', (event) => {
        // Settings Menu
        const isSettingsMenuVisible = !settingsMenu.classList.contains('hidden');
        const isClickInsideSettingsMenu = settingsMenu.contains(event.target);
        const isClickOnSettingsButton = settingsButton.contains(event.target);

        if (isSettingsMenuVisible && !isClickInsideSettingsMenu && !isClickOnSettingsButton) {
            settingsMenu.classList.add('hidden'); // Hide settings menu
        }

        // Games List (full page) - does not close on outside click now
        // Partner Page (full page) - does not close on outside click now
        // Themes Page (full page) - does not close on outside click now
        // About Page (full page) - does not close on outside click now

    });


    // Handle close game button click (inside iframe view)
    closeGameButton.addEventListener('click', () => {
        gameIframeContainer.classList.add('hidden'); // Hide the iframe container
        gameIframe.src = ""; // Stop the game by clearing the source
        // Decide where to go back - maybe the last page visited? For now, go back to Games List.
        gamesListContainer.classList.remove('hidden'); // Show the games page again
    });

    // Handle fullscreen game button click
    fullscreenGameButton.addEventListener('click', () => {
        if (gameIframe.requestFullscreen) {
            gameIframe.requestFullscreen();
        } else if (gameIframe.mozRequestFullScreen) { /* Firefox */
            gameIframe.mozRequestFullScreen();
        } else if (gameIframe.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
            gameIframe.webkitRequestFullscreen();
        } else if (gameIframe.msRequestFullscreen) { /* IE/Edge */
            gameIframe.msRequestFullscreen();
        }
    });


    // Apply custom title
    applyTitleButton.addEventListener('click', () => {
        const newTitle = titleInput.value.trim();
        if (newTitle) {
            document.title = newTitle;
            localStorage.setItem('savedTitle', newTitle); // Save title
            titleInput.value = ''; // Clear input
        }
    });

     // Apply custom favicon
    applyFaviconButton.addEventListener('click', () => {
        const newFaviconUrl = faviconInput.value.trim();
        if (newFaviconUrl) {
            let finalFaviconUrl;
            // Check if the URL looks like a path or a full URL
            if (newFaviconUrl.startsWith('http://') || newFaviconUrl.startsWith('https://')) {
                finalFaviconUrl = newFaviconUrl;
            } else {
                // Assume it's a local path if not a full URL
                finalFaviconUrl = '/' + newFaviconUrl.replace(/^\//, ''); // Ensure it starts with a single slash
            }
            faviconLink.href = finalFaviconUrl;
            localStorage.setItem('savedFavicon', finalFaviconUrl); // Save favicon URL
            faviconInput.value = ''; // Clear input
        }
    });

    // Handle cloak preset clicks
    cloakOptions.forEach(option => {
        option.addEventListener('click', () => {
            const preset = option.getAttribute('data-cloak');
            let title = 'FIGS MATH';
            let favicon = '/icon_transparent.png'; // Default transparent fig

            switch (preset) {
                 case 'default':
                    // Already set above
                    break;
                case 'google-drive':
                    title = 'My Drive - Google Drive';
                    favicon = '/drive.png'; // Use the local asset path
                    break;
                case 'google-chrome':
                    title = 'New Tab';
                    favicon = '/Google_chrome.png'; // Use the local asset path
                    break;
                // Add more cases for other presets
            }
            document.title = title;
            faviconLink.href = favicon;
            localStorage.setItem('savedTitle', title); // Save preset title
            localStorage.setItem('savedFavicon', favicon); // Save preset favicon
        });
    });


    // Change theme from quick access buttons in settings (implicit save happens inside applyTheme)
    themeButtons.forEach(button => {
        button.addEventListener('click', () => {
            const themeClass = 'theme-' + button.getAttribute('data-theme');
             // Find the theme object to get the effect
            const selectedTheme = availableThemes.find(theme => theme.class === themeClass);
            // Pass the effect to applyTheme
            const effect = selectedTheme ? selectedTheme.effect : null;
            applyTheme(themeClass, effect);
        });
    });

    // --- Initialization ---

    // Load saved settings from localStorage
    const savedThemeClass = localStorage.getItem('savedThemeClass');
    const savedEffect = localStorage.getItem('savedEffect');
    const savedBgColor = localStorage.getItem('savedBgColor');
    const savedTextColor = localStorage.getItem('savedTextColor');
    const savedTitle = localStorage.getItem('savedTitle');
    const savedFavicon = localStorage.getItem('savedFavicon');
    const betterUiState = localStorage.getItem('betterUiActive');


    // Apply saved Theme and Colors
    // Check for saved custom colors first if custom theme is saved
    if (savedThemeClass === 'theme-custom' && savedBgColor && savedTextColor) {
        document.documentElement.style.setProperty('--custom-bg', savedBgColor);
        document.documentElement.style.setProperty('--custom-text', savedTextColor);
        applyTheme('theme-custom', savedEffect); // Apply custom theme class and saved effect
        // Update color pickers in settings menu
        bgColorInput.value = savedBgColor;
        textColorInput.value = savedTextColor;
    } else if (savedThemeClass) {
         // Check if the saved theme class exists in the availableThemes list
         const themeExists = availableThemes.some(theme => theme.class === savedThemeClass);
         if (themeExists) {
              // Find the theme object to get the effect
              const selectedTheme = availableThemes.find(theme => theme.class === savedThemeClass);
              // Handle the 'stars' effect case explicitly - it's not an effect layer
              const effectToApply = (selectedTheme && selectedTheme.effect === 'stars') ? null : selectedTheme ? selectedTheme.effect : null;
              applyTheme(savedThemeClass, effectToApply); // Apply saved theme class and its associated effect (excluding 'stars' effect layer)
         } else {
            // If saved theme class is not valid, apply default dark theme
            applyTheme('theme-dark');
         }
    } else {
        // Apply default dark theme if nothing is saved (without saving it)
        body.classList.add('theme-dark');
    }


    // Apply saved Title
    if (savedTitle) {
        document.title = savedTitle;
    } else {
        // Set default title if nothing saved
        document.title = 'FIGS MATH';
    }

    // Apply saved Favicon
     if (savedFavicon) {
         faviconLink.href = savedFavicon;
     } else {
        // Set default favicon if nothing saved
        faviconLink.href = '/icon_transparent.png'; // Use the transparent fig icon
     }


    // Check localStorage for Better UI state on load
    if (betterUiState === 'true') {
        betterUiSwitch.checked = true;
        body.classList.add('better-ui-active');
    } else {
         betterUiSwitch.checked = false;
         body.classList.remove('better-ui-active'); // Ensure class is removed if state is false or not set
    }


    renderGames(); // Render the initial list of games
    renderThemes(); // Render the initial list of themes

    // Initialize page state: only show initial screen and set default favicon (favicons handled by load logic above now)
    initialScreen.classList.remove('hidden'); // Ensure initial screen is visible
    homeContent.classList.add('hidden'); // Hide home content
    gamesListContainer.classList.add('hidden'); // Hide games list page
    partnerPageContainer.classList.add('hidden'); // Hide partner page
    themesPageContainer.classList.add('hidden'); // Hide themes page
    aboutPageContainer.classList.add('hidden'); // Hide about page
    gameIframeContainer.classList.add('hidden'); // Hide iframe container
    // Removed home icon button hide
    // homeIconButton.classList.add('hidden'); // Hide new home icon button
    discordLink.classList.add('hidden'); // Hide discord icon
    partnersButton.classList.add('hidden'); // Hide partners icon
    gamesButton.classList.add('hidden'); // Hide games icon
    aboutButton.classList.add('hidden'); // Hide about icon
    settingsButton.classList.add('hidden'); // Hide settings icon
    settingsMenu.classList.add('hidden'); // Hide settings menu

});